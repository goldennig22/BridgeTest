<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Product;
use App\Models\User;

class TestController extends Controller
{
    //
    public function store(Request $request)
    {
        $request->validate([
            'name'=> 'required|max:255',
            'price'=> 'required|numeric',
            'quantity'=> 'required|numeric',
        ]);

        $product = new Product;
        $product->name = $request->name; 
        $product->price = $request->price; 
        $product->quantity = $request->quantity; 
        $product->user_id = session('id');
        $product->save();
        return back()->with('status','Product stored successfully');
    }

    public function Edit(Request $request)
    {
        $request->validate([
            'name'=> 'required|max:255',
            'price'=> 'required|numeric',
            'quantity'=> 'required|numeric',
            'id'=> 'required|numeric',
        ]);

        $product = Product::find($request->id);
        if ($product) {
            $product->name = $request->name; 
            $product->price = $request->price; 
            $product->quantity = $request->quantity; 
            $product->save();
            return back()->with('status','Product stored successfully');
        }else {
            return back()->with('error','Product Not found');
            
        }
    }

    public function deleteProd(Request $request)
    {
        $request->validate([
            'id'=> 'required|numeric',
        ]);

        $product = Product::find($request->id);
        if ($product) {
            $product->delete();
            return back()->with('status','Product successfully deleted');
        }else {
            return back()->with('error','Unknown Product');
        }
    }

    public function dashboard()
    {
        if (!session('id')) {
            $user= User::where('email',session('email'))->first();
            if ($user) {
                session(['id'=>$user->id,'name'=>$user->name]);
            }
        }
        $products = Product::where('user_id',session('id'))->get();
        return view('dashboard',['products'=>$products]); 
    }
}
